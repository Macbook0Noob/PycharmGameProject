# This game is an RPG styled game where players will have to crawl through this corrupted dungeon to survive
# Glitch/Broken reality theme, affects the battles and aesthetic
# Game over if the glitches/corruptions get too potent
# 4 playable fighters when battling
# Special types/Affinities: Fire, Water, Air, Storm

# Main file that runs and loads in the game

import pygame, sys
from sprites import *
from config import *
from pygame.locals import QUIT

# Main game class that initializes and runs the game while the program is on
class Game:
    global BACKGROUNDIMG, canvas, selected_target, party_members, enemies, allEntities, bora, mizli, aer, voli, corrupted

    # Function to initialize the game
    def __init__(self):
        pygame.init()
        self.canvas = pygame.display.set_mode(WINSIZE)
        canvas = self.canvas
        self.clock = pygame.time.Clock()
        self.running = True
        self.font = pygame.font.Font("GlitchingDemoRegular.ttf", 30)
        pygame.display.set_caption("EEEEEEEEEEEEEE")

        # Loads the backgrounds of each screen in game
        # Background of the free roam screen
        self.background = pygame.image.load("dungeon.jpg")
        BACKGROUNDIMG = pygame.transform.scale(self.background, WINSIZE)
        self.background = BACKGROUNDIMG

        # Background of the battle sequence
        self.battle_background = pygame.image.load("glitch.jpg")

        # Background of the game over screen
        self.gameover = pygame.image.load("Roeally_bro.png")
        GAMEOVERBACKGROUND = pygame.transform.scale(self.gameover, WINSIZE)
        self.gameover = GAMEOVERBACKGROUND

        # Background of the title card
        self.intro_background = pygame.image.load("IntroScreen.png")
        INTROSCREEN = pygame.transform.scale(self.intro_background, WINSIZE)
        self.intro_background = INTROSCREEN

        # Background of the tutorial screen
        self.tutorial_background = pygame.image.load("tutorialScreen.png")
        TUTORIALSCREEN = pygame.transform.scale(self.tutorial_background, WINSIZE)
        self.tutorial_background = TUTORIALSCREEN

    # Function to initialize the mapping of each floor in the game
    # For each row in the tilemap at every placement, create the necessary objects on each floor
    def createTilemap(self):
        for i, row in enumerate(tilemap):
            for j, column in enumerate(row):
                if column == "W":
                    Barrier(self, j, i, wallimg)
                if column == "B":
                    Barrier(self, j, i, pillarimg)
                if column == "P":
                    self.player = Player(self, (j * 0.985), i)
                if column == "E":
                    corruption = Enemy(self, j, i)
                    # Responsible for keeping track of how many enemies are left in order to clear out the floor
                    total_enemies.append(corruption)

    # Function to create a new game and refresh the sprites for each new start
    def new(self):
        self.playing = True
        self.all_sprites = pygame.sprite.LayeredUpdates()
        self.obstacles = pygame.sprite.LayeredUpdates()
        self.fighters = pygame.sprite.LayeredUpdates()
        self.enemies = pygame.sprite.LayeredUpdates()
        self.attacks = pygame.sprite.LayeredUpdates()
        self.createTilemap()

    # Main function to help close the program when exited and recording player input
    def events(self):
        for event in pygame.event.get():
            if event.type == QUIT:
                self.playing = False
                self.running = False

            # Does the attack animation and mechanic when the spacebar is pressed,
            # spawning the sprite in the appropriate direction
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    if self.player.facing == "up":
                        Attack(self, self.player.rect.x, self.player.rect.y - PLAYER_SIZE[1] + 10)
                    if self.player.facing == "down":
                        Attack(self, self.player.rect.x, self.player.rect.y + PLAYER_SIZE[1] - 10)
                    if self.player.facing == "left":
                        Attack(self, self.player.rect.x - PLAYER_SIZE[0] + 10, self.player.rect.y)
                    if self.player.facing == "right":
                        Attack(self, self.player.rect.x + PLAYER_SIZE[0] - 10, self.player.rect.y)

    # Function to constantly update the game while it is running
    def update(self):
        self.all_sprites.update()

    # Loads the necessary sprites and game elements into the game
    # Also displays the corruption timer that slowly drains as the game runs
    def draw(self):
        self.canvas.blit(self.background, (0, 0))
        self.all_sprites.draw(self.canvas)
        pygame.draw.rect(self.canvas, LAVENDER, (20, 660, 550, 170))
        corrupted.drawTimer(corruptSuccess)
        self.draw_text(f"Time before corruption is irreversible:", timer, MAGENTA, 50, 680)
        self.clock.tick(120)
        pygame.display.update()

    # Function that helps run the game continuously
    def main(self):
        global corruptSuccess
        #game loop
        while self.playing:
            self.events()
            self.update()
            self.draw()
            # Ticks down the corruption timer during gameplay
            corruptSuccess -= 1

            # If the set value of the corruption reaches 0, the player has game over'd
            if corruptSuccess < 1:
                corruptSuccess = 0
                self.playing = False

    # Function that activates when all your party members die or the corruption timer hits 0
    def game_over(self):
        global corruptSuccess

        # Initializes all the elements of the game over screen when the screen is activated
        restart_button = Button(535, 450, 360, 110, WHITE, BLACK, "Restart", 150)
        deathTextTop = death.render(f"You died?", True, WHITE)
        deathTextBottom = death.render(f"That's cringe bROE", True, WHITE)

        # Deletes all sprites loaded when a game over occurs
        for sprite in self.all_sprites:
            sprite.kill()

        # While loop that runs to load the textures and buttons of the screen
        while self.running:

            # Records mouse position and action
            mousePos = pygame.mouse.get_pos()
            mousePressed = pygame.mouse.get_pressed()

            # Filler code to prevent the window from breaking with an attempted close
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False

            # Restarts the game from a clean state when the restart button is clicked
            if restart_button.is_pressed(mousePos, mousePressed):
                self.new()
                self.main()
                corruptSuccess = 10000

            # Draws the background, buttons, and text of the screen
            self.canvas.blit(self.gameover, (0, 0))
            self.canvas.blit(restart_button.image, restart_button.rect)
            self.canvas.blit(deathTextTop, (450, 10))
            self.canvas.blit(deathTextBottom, (180, 600))
            self.clock.tick(120)
            pygame.display.update()

    # Function that boots up a title screen when the player opens the game
    def intro_screen(self):
        global tutorial
        # Loads the textures and text displayed on the title screen when the program is opened
        start = True # Variable that determines whether the intro screen should be displayed or not
        tutorial = False # Variable that determiens whehter the tutorial should be displayed or not
        start_button = Button(300, WINCENTER[1] + 200, 360, 110, WHITE, BLACK, "EXPLORE", 150)
        tutorial_button = Button(800, WINCENTER[1] + 200, 360, 110, WHITE, BLACK, "TUTORIAL", 150)
        introText = intro.render(f"Vyshareth", True, WHITE)
        creatorText = creator.render(f"By MacbookNoob", True, WHITE)

        # While start is true, the intro screen is displayed
        while start:
            # Records mouse position and action
            mousePos = pygame.mouse.get_pos()
            mousePressed = pygame.mouse.get_pressed()

            # Closes the program if exited
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    start = False
                    self.running = False

            # Runs the actual gameplay of the game when the start button is clicked
            if start_button.is_pressed(mousePos, mousePressed):
                start = False

            # Opens the tutorial screen when the tutorial button is clicked
            if tutorial_button.is_pressed(mousePos, mousePressed):
                tutorial = True
                self.tutorial_screen()

            # Displays all the textures, text, and background onto the intro screen
            self.canvas.blit(self.intro_background, (0, 0))
            self.canvas.blit(start_button.image, start_button.rect)
            self.canvas.blit(tutorial_button.image, tutorial_button.rect)
            self.canvas.blit(introText, (180, WINCENTER[1] - 400))
            self.canvas.blit(creatorText, (350, WINCENTER[1] - 140))
            self.clock.tick(120)
            pygame.display.update()

    # Function that handles the interactivity and UI of the tutorial
    def tutorial_screen(self):
        global tutorial
        back_button = Button(0, WINCENTER[1] + 180, 200, 200, WHITE, GRAY, "help", 1)

        # While the tutorial variable is true, display the tutorial screen
        while tutorial:
            # Records mouse position and action
            mousePos = pygame.mouse.get_pos()
            mousePressed = pygame.mouse.get_pressed()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # Filler code to prevent the window from breaking
                    self.running = False

            # Brings player back to the intro screen if the back button is pressed
            if back_button.is_pressed(mousePos, mousePressed):
                tutorial = False

            # Displays all the textures, buttons, and background onto the tutorial when active
            self.canvas.blit(self.tutorial_background, (0, 0))
            self.canvas.blit(back_button.image, back_button.rect)
            self.canvas.blit(backButton, (0, 580))
            self.clock.tick(120)
            pygame.display.update()

    # Function to place text on screen when called
    def draw_text(self, text, font, text_col, pos_x, pos_y):
        stat = font.render(text, True, text_col)
        self.canvas.blit(stat, (pos_x, pos_y))

    # Initializes all the playable characters in combat before the game launches
    # Fighter class info:
    # X position, Y position, Name, Health, Normal Attack Power, Magic Attack Power, Magic Meter, Healing/Guarding, Sprite
    def playerInitializer(self):
        global bora, bora_health_bar, mizli, mizli_health_bar, aer, aer_health_bar, voli, voli_health_bar
        bora = Fighter(self, 700, 500, "Bora", 2000, 100, 200, 12, 125, BORA)
        bora_health_bar = HealthBar(1075, 65, bora.hp, bora.max_hp, bora.sp, bora.spmeter, self.canvas)
        mizli = Fighter(self, 875, 400, "Mizli", 1600, 75, 250, 15, 100, MIZLI)
        mizli_health_bar = HealthBar(1075, 180, mizli.hp, mizli.max_hp, mizli.sp, mizli.spmeter, self.canvas)
        aer = Fighter(self, 1050, 550, "Aer", 4000, 50, 150, 25, 200, AER)
        aer_health_bar = HealthBar(700, 65, aer.hp, aer.max_hp, aer.sp, aer.spmeter, self.canvas)
        voli = Fighter(self, 1225, 420, "Voli", 1000, 250, 500, 8, 50, VOLI)
        voli_health_bar = HealthBar(700, 180, voli.hp, voli.max_hp, voli.sp, voli.spmeter,  self.canvas)

    # Initializes in the corruption timer that displays how much time the player has to clear the floor before losing
    def createTimer(self):
        global corrupted, corruptedBattle

        # Timer displayed when roaming around the dungeon
        corrupted = Countdown(50, 725, corruptSuccess, corruptMax, self.canvas)

        # Timer displayed when in battle
        corruptedBattle = Countdown(10, 220, corruptSuccess, corruptMax, self.canvas)

    # Loads the battle sequence when a successful attack lands
    def battle_screen(self):
        global current_fighter, action_cooldown, action_wait_time, party_members, enemies, allEntities,\
        corruptSuccess, corruptMax
        battle = True
        allEntities = []
        party_members = []
        enemies = []

        # Provides your party members that are usable in a fight
        party_members.append(bora)
        party_members.append(mizli)
        party_members.append(aer)
        party_members.append(voli)

        # Information about every possible enemy
        # Used Fighter class information: X Position, Y Position, Name, Health, Normal Attack Power, Sprite
        glitch = Fighter(self, 400, 575, "D@ge", 500, 50, 0, 0, 0, DOGE)
        hippoe = Fighter(self, 250, 450, "H|pp@e", 2000, 100, 0, 0, 0, HIPPOE)
        BBBunny = Fighter(self, 300, 475, "BnUUyBB", 750, 75, 0, 0, 0, BB)
        dagshund = Fighter(self, 200, 400, "@|awg$hun@|", 3000, 250, 0, 0, 0, DAGSHUND)
        mooth = Fighter(self, 200, 300, "M@@th", 2000, 500, 0, 0, 0, MOOTH)
        sunfish = Fighter(self, 50, 200, "$unf!$h", 5000, 500, 0, 0, 0, SUNFISH)

        # Adds all loaded enemy into an enemies list that is used for random selection
        enemies.append(glitch)
        enemies.append(BBBunny)
        enemies.append(hippoe)
        enemies.append(dagshund)
        enemies.append(mooth)
        enemies.append(sunfish)

        # Randomly chooses an enemy for the player to fight at each encounter
        enemy = random.choice(enemies)
        enemy_health_bar = HealthBar(10, 73, enemy.hp, enemy.max_hp, enemy.sp, enemy.spmeter, self.canvas)

        # All loaded entities in every battle
        allEntities.append(bora)
        allEntities.append(mizli)
        allEntities.append(aer)
        allEntities.append(voli)
        allEntities.append(enemy)

        # Weaknesses of each enemy
        bora_weak = glitch
        bora_weaker = dagshund
        mizli_weak = hippoe
        aer_weak = BBBunny
        voli_weak = mooth
        voli_weaker = sunfish

        # Loads in the interactive buttons for each possible action of each player fighter
        regular_attack = Button(bora.x - 30, bora.y, 120, 40, WHITE, BLACK, "Attack", 60)
        special_attack = Button(bora.x - 30, bora.y - 50, 120, 40, WHITE, BLACK, "Magic", 60)
        guard = Button(bora.x - 30, bora.y - 100, 120, 40, WHITE, BLACK, "Heal", 60)
        retreat = Button(bora.x - 30, bora.y - 150, 120, 40, WHITE, BLACK, "Retreat", 60)

        # Loop to continuosly update data about each battle
        while battle:
            self.clock.tick(120)
            # Ticks down the corruption timer
            action_cooldown += 1
            corruptSuccess -= 1
            # Records mouse position and action
            mouse_pos = pygame.mouse.get_pos()
            mouse_pressed = pygame.mouse.get_pressed()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    # Filler code to prevent the loaded windows from breaking
                    self.running = False

            # Loads in the background UI elements
            self.canvas.blit(self.battle_background, (0, 0))
            pygame.draw.rect(self.canvas, BLACK, (0, 0, 550, 280))
            pygame.draw.rect(self.canvas, BLACK, (680, 0, 900, 235))

            # Updates the health and magic bar of each fighter continuously
            # Bora's stats
            self.draw_text(f"{bora.name} HP: {bora.hp}", font, RED, 1075, 5)
            bora_health_bar.drawHP(bora.hp)
            bora_health_bar.drawSP(bora.sp)
            bora.draw(self.canvas)
            # Mizli's stats
            self.draw_text(f"{mizli.name} HP: {mizli.hp}", font, BLUE, 1075, 115)
            mizli_health_bar.drawHP(mizli.hp)
            mizli_health_bar.drawSP(mizli.sp)
            mizli.draw(self.canvas)
            # Aer's stats
            self.draw_text(f"{aer.name} HP: {aer.hp}", font, GREEN, 700, 5)
            aer_health_bar.drawHP(aer.hp)
            aer_health_bar.drawSP(aer.sp)
            aer.draw(self.canvas)
            # Voli's stats
            self.draw_text(f"{voli.name} HP: {voli.hp}", font, YELLOW, 700, 115)
            voli_health_bar.drawHP(voli.hp)
            voli_health_bar.drawSP(voli.sp)
            voli.draw(self.canvas)

            # Displays the current selected character that can perform an action
            self.draw_text(f"Current Fighter: {allEntities[current_fighter].name}", font, WHITE, 10, 100)

            # Displays the health of the enemy
            self.draw_text(f"{enemy.name} HP: {enemy.hp}", font, WHITE, 10, 5)
            enemy_health_bar.drawHP(enemy.hp)
            enemy.draw(self.canvas)

            # Displays the corruption timer during gameplay at a more convenient location
            corruptedBattle.drawTimer(corruptSuccess)
            self.draw_text(f"Time before corruption is irreversible:", timer, MAGENTA, 10, 170)

            # Displays all the defined buttons during battle
            self.canvas.blit(regular_attack.image, regular_attack.rect)
            self.canvas.blit(special_attack.image, special_attack.rect)
            self.canvas.blit(guard.image, guard.rect)
            self.canvas.blit(retreat.image, retreat.rect)

            # A loop that records what button is pressed for each playable fighter the player can control (Right side sprites)
            for player in party_members:

                #If "Attack" is pressed, a regular attack will be performed and the turn will be passed on
                if regular_attack.is_pressed(mouse_pos, mouse_pressed):
                    if action_cooldown > action_wait_time:
                        party_members[current_fighter].strike(enemy)
                        action_cooldown = 0
                        current_fighter += 1

                # If "Magic" is pressed, a special attack will be performed and the turn will be passed on
                # If the fighter is super effective against a specific enemy, the damage will be doubled
                # After the attack, a turn will be passed on
                if special_attack.is_pressed(mouse_pos, mouse_pressed):
                    if action_cooldown > action_wait_time:
                        if party_members[current_fighter].sp > 0:
                            party_members[current_fighter].magic_strike(enemy)
                            party_members[current_fighter].sp -= 1

                            # If the enemy is D@ge or @|awg$hun@|, Bora will do double damage
                            if bora.alive == True:
                                if current_fighter == 0:
                                    if enemy == bora_weak or enemy == bora_weaker:
                                        party_members[current_fighter].magic_strike(enemy)
                            # If the enemy is H|pp@e, Mizli will do double damage
                            if mizli.alive == True:
                                if current_fighter == 1:
                                    if enemy == mizli_weak:
                                        party_members[current_fighter].magic_strike(enemy)
                            # If the enemy is BnUUyBB, Aer will do double damage
                            if aer.alive == True:
                                if current_fighter == 2:
                                    if enemy == aer_weak:
                                        party_members[current_fighter].magic_strike(enemy)
                            # If the enemy is M@@wth or $unfi$h, Voli will do double damage
                            if voli.alive == True:
                                if current_fighter == 3:
                                    if enemy == voli_weak or enemy == voli_weaker:
                                        party_members[current_fighter].magic_strike(enemy)

                            action_cooldown = 0
                            current_fighter += 1

                        # If the fighter ran out of SP, they are no longer able to use magic attacks
                        else:
                            pygame.draw.rect(self.canvas, LAVENDER, (80, 390, 1300, 140))
                            self.draw_text(f"No SP! Too weak to use magic!", warning, RED, 100,
                                           400)

                # If "Guard" is clicked, the current fighter will heal themselves a set amount, then passing on a turn
                if guard.is_pressed(mouse_pos, mouse_pressed):
                    if action_cooldown > action_wait_time:
                        party_members[current_fighter].hp += party_members[current_fighter].defense

                        # Preventing cheesing with healths going above their max ammount
                        if allEntities[current_fighter].hp > allEntities[current_fighter].max_hp:
                            allEntities[current_fighter].hp = allEntities[current_fighter].max_hp
                        action_cooldown = 0
                        current_fighter += 1

                # If "retreat" is pressed, the battle will end and the player can resume back to free roam faster
                if retreat.is_pressed(mouse_pos, mouse_pressed):
                    if action_cooldown > action_wait_time:
                        success = party_members[current_fighter].run(1)
                        action_cooldown = 0
                        current_fighter += 1

                        # Only occurs if the retreating is determined successfully by chance
                        if success == True:
                            battle = False
                            self.running = False
                            action_cooldown = 0
                            current_fighter = 0

            # Every cycle through all fighters, the enemy will randomly determine a target to attack
            if current_fighter == 0:
                self.enemy_target = random.choice(party_members)

            # Once the active turn has cycled through all players, the opponents will go next
            if current_fighter == len(party_members):
                if enemy.alive == True:
                    action_cooldown += 1
                    if action_cooldown >= action_wait_time:
                        enemy.strike(self.enemy_target)
                        current_fighter = 0
                        action_cooldown = 0

            # If the enemies die, the player has won and free roam will continue
            # The corruption timer will also extend as a glitch has been dealt with
            if enemy.alive == False:
                action_cooldown = 0
                current_fighter = 0
                flee = 0
                corruptSuccess += 1000
                battle = False

                # Small code to prevent the corruption timer from exceeding its predetermined amount
                if corruptSuccess > corruptMax:
                    corruptSuccess = corruptMax

            # If any fighter reaches 0 health, they are removed from the fight and unable to be used again.
            if allEntities[current_fighter].hp < 1:
                allEntities.pop(current_fighter)
                party_members.pop(current_fighter)

            # If all party members die, the game is over
            if len(party_members) == 0:
                battle = False
                self.playing = False

            # If the player runs out of time to kill all the enemies, they also receieve a gameover
            if corruptSuccess < 1:
                battle = False

            pygame.display.update()

# Creates a new game when starting the program
game = Game()
game.intro_screen()
game.playerInitializer()
game.createTimer()
game.new()

# Runs the game until a game over in some way occurs
while game.running:
    game.main()
    game.game_over()

# Closes the game and program when finished
pygame.quit()
sys.exit()