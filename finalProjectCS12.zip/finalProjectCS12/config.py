# File that is responsible for predeterming constants used in the game and other important variables
import pygame

# Setup Constants
WINSIZE = (1440, 800)
WINCENTER = (720, 400)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
YELLOW = (255, 255, 0)
MAGENTA = (255, 0, 255)
LAVENDER = (140, 0, 210)
GRAY = (128, 128, 128)

# Free Roam Gameplay Constants
PLAYER_X = 500
PLAYER_Y = 200
GROUND_LAYER = 1
BLOCK_LAYER = 2
PILLAR_LAYER = 3
PLAYER_LAYER = 4
ENEMY_LAYER = 4
PLAYER_SPEED = 2
ENEMY_SPEED = 1
PLAYER_SIZE = (50, 50)
WALL_SIZE = (32, 32)
PILLAR_SIZE = (64, 64)
HAMMER_SIZE = (60, 60)
BUTTON_SIZE = (200, 200)
TILESIZE = 32

# Battle Sequence Constants
BATTLE_SIZE = (1400, 1400)
FIGHTER_SIZE = (250, 250)
DOGE_SIZE = (150, 150)
BB_SIZE = (250, 250)
HIPPOE_SIZE = (320, 320)
DAGSHUND_SIZE = (350, 350)
MOOTH_SIZE = (300, 300)
SUNFISH_SIZE = (600, 600)

# Battle Variables
current_fighter = 0
total_fighters = 4
selected_target = 0
action_cooldown = 0
action_wait_time = 200
flee = 0
total_enemies = []
corruptSuccess = 10000
corruptMax = 10000

# Initializes all fonts as an object to be rendered properly into the game
pygame.font.init()
font = pygame.font.SysFont("Times New Roman", 50, False, False)
warning = pygame.font.SysFont("Times New Roman", 100, False, False)
intro = pygame.font.SysFont("Times New Roman", 250, True, False)
creator = pygame.font.SysFont("Times New Roman", 100, False, False)
timer = pygame.font.SysFont("Times New Roman", 30, True, False)
death = pygame.font.SysFont("Impact", 150, False, False)

# Specific Textures for objects
wall = pygame.image.load("wall_texture.png")
wallimg = pygame.transform.scale(wall, WALL_SIZE)
pillar = pygame.image.load("pillar_texture.png")
pillarimg = pygame.transform.scale(pillar, PILLAR_SIZE)
backbutton = pygame.image.load("backButton.png")
backButton = pygame.transform.scale(backbutton, BUTTON_SIZE)

# Sprites of all fighter characters in combat
BORA = pygame.image.load("New_Bora.png")
mizli = pygame.image.load("Mizli.png")
MIZLI = pygame.transform.scale(mizli, FIGHTER_SIZE)
aer = pygame.image.load("Aer.png")
AER = pygame.transform.scale(aer, FIGHTER_SIZE)
voli = pygame.image.load("Voli.png")
VOLI = pygame.transform.scale(voli, FIGHTER_SIZE)

# Sprites of all possible enemies in combat
doge = pygame.image.load("enemy.png")
DOGE = pygame.transform.scale(doge, DOGE_SIZE)
bunny = pygame.image.load("GlitchedBB.png")
BB = pygame.transform.scale(bunny, BB_SIZE)
hippo = pygame.image.load("GlitchedHippoe.png")
HIPPOE = pygame.transform.scale(hippo, HIPPOE_SIZE)
dog = pygame.image.load("GlitchedDagshund.png")
DAGSHUND = pygame.transform.scale(dog, DAGSHUND_SIZE)
moth = pygame.image.load("GlitchedMooth.png")
MOOTH = pygame.transform.scale(moth, MOOTH_SIZE)
fish = pygame.image.load("GlitchedSunfish.png")
SUNFISH = pygame.transform.scale(fish, SUNFISH_SIZE)

# 1440 x 800 tilemap of the explorable dungeon floor(45 rows x 25 columns)
# W = Wall
# B = Pillar
# P = Player
# E = Enemies
# . = Nothing

tilemap = [
    'BWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWWB',
    'W........W.....W............................W',
    'W........B.....B...........WWW..............W',
    'W...B.....E..............E.WWW......B.......W',
    'W...W......................WWW..........B...W',
    'W...W.......B....BWWWWWB................W...W',
    'W.E.W........W..........................W.E.W',
    'W...W.........W.........BWWWWBWWWWB.....W...W',
    'W...W..E.......W.............W..........B...W',
    'W...B...........B..E.........W........E.....W',
    'W..........B..............B..W....BWWB......W',
    'W.........................W..B..............W',
    'W..................B......W.................W',
    'W.........WW.......W......W.....E..B........W',
    'W.....B...WW.......W......BWWWB.......B.....W',
    'W.....W............B..................W.....W',
    'W..E..W...............................W..E..W',
    'W.....B.......B...............B.......B.....W',
    'W.....W.......W...............W.......W.....W',
    'W.....W...B...W...............W...B...W.....W',
    'BWWWWWWWWWWWWWWWWWWWB.P.BWWWWWWWWWWWWWWWWWWWB',
    'WWWWWWWWWWWWWWWWWWWWW...WWWWWWWWWWWWWWWWWWWWW',
    'WWWWWWWWWWWWWWWWWWWWW...WWWWWWWWWWWWWWWWWWWWW',
    'WWWWWWWWWWWWWWWWWWWWW...WWWWWWWWWWWWWWWWWWWWW',
    'BWWWWWWWWWWWWWWWWWWWBWWWBWWWWWWWWWWWWWWWWWWWB',
]