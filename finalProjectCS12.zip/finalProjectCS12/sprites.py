# File that's responsible for managing different classes of each element of the game and creating their sprites
from config import *
import random



# Player class that determines the functionality and mechanics for the player while free roaming
class Player(pygame.sprite.Sprite):

    # Initializes the mechanics of the player in free roam
    def __init__(self, game, pos_x, pos_y):
        # Loading Texture of the free roaming player
        play = pygame.image.load("Cat.png")
        playerimg = pygame.transform.scale(play, PLAYER_SIZE)

        # Loads the player into the game with its proper sprite and layering
        super().__init__()
        self.game = game
        self._layer = PLAYER_LAYER
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)

        # Determines the dimensions of the player and starting position
        self.x = pos_x * TILESIZE
        self.y = pos_y * TILESIZE
        self.width = PLAYER_SIZE[0]
        self.height = PLAYER_SIZE[1]
        self.x_change = 0
        self.y_change = 0
        self.facing = "down"
        self.image = pygame.Surface([self.width, self.height])

        # Hitbox of the player
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

        # Loads the texture onto the player object
        self.image.blit(playerimg, (0, 0))
        self.image.set_colorkey(BLACK)

    # Updates the hitbox and player position over time while the game is running
    def update(self):
        self.movement()
        self.rect.x += self.x_change
        self.collision("x")
        self.rect.y += self.y_change
        self.collision("y")
        self.encounter()
        self.x_change = 0
        self.y_change = 0

    # Causes the player the move with a key press (Only WASD)
    def movement(self):
        keys = pygame.key.get_pressed()
        if keys[pygame.K_w]:
            self.y_change -= PLAYER_SPEED
            self.facing = "up"
        if keys[pygame.K_s]:
            self.y_change += PLAYER_SPEED
            self.facing = "down"
        if keys[pygame.K_d]:
            self.x_change += PLAYER_SPEED
            self.facing = "right"
        if keys[pygame.K_a]:
            self.x_change -= PLAYER_SPEED
            self.facing = "left"

    # Detects if any obstacle is in the way of the player and stops their movement accordingly
    def collision(self, direction):
        # Stops horizontal movement
        if direction == "x":
            hits = pygame.sprite.spritecollide(self, self.game.obstacles, False)
            if hits:
                if self.x_change > 0:
                    self.rect.x = hits[0].rect.left - self.rect.width
                if self.x_change < 0:
                    self.rect.x = hits[0].rect.right

        # Stops veritcal movement
        if direction == "y":
            hits = pygame.sprite.spritecollide(self, self.game.obstacles, False)
            if hits:
                if self.y_change > 0:
                    self.rect.y = hits[0].rect.top - self.rect.height
                if self.y_change < 0:
                    self.rect.y = hits[0].rect.bottom

    # Activates a battle sequence when a player collides with an enemy
    def encounter(self):
        global current_fighter
        hits = pygame.sprite.spritecollide(self, self.game.enemies, True)
        if hits:
            self.game.battle_screen()
            # Removes the enemy from the free roam screen once the collision occurs
            total_enemies.pop(0)



# Enemy class that creates the functions of the enemies while free roaming the floors
class Enemy(pygame.sprite.Sprite):

    # Initializes the mechanics of enemies
    def __init__(self, game, pos_x, pos_y):

        # Loading Texture of the enemy
        enemy = pygame.image.load("Glitchorvirus.png")
        enemyimg = pygame.transform.scale(enemy, PLAYER_SIZE)

        # Loads each enemy into the game with its proper sprite and layering
        super().__init__()
        self.game = game
        self._layer = ENEMY_LAYER
        self.groups = self.game.all_sprites, self.game.enemies
        pygame.sprite.Sprite.__init__(self, self.groups)

        # Determines the dimensions and hitbox of the enemies
        self.x = pos_x * TILESIZE
        self.y = pos_y * TILESIZE
        self.width = PLAYER_SIZE[0]
        self.height = PLAYER_SIZE[1]
        self.x_change = 0
        self.y_change = 0
        self.image = pygame.Surface([self.width, self.height])

        # Hitbox of the enemies
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

        # Determines the enemy's pathing during the free roam gameplay
        self.facing = random.choice(["up", "down"])
        self.animation_loop = 1
        self.movement_loop = 0
        # Randomly determined distance the enemies will travel
        self.max_travel = random.randint(3, 60)

        # Loads the texture onto the enemy object
        self.image.blit(enemyimg, (0, 0))
        self.image.set_colorkey(BLACK)

    # Updates the hitbox and movement of the enemies while the program is running
    def update(self):
        self.movement()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.x_change = 0
        self.y_change = 0

    # Defines the pathing the enemies will take based off its "max_travel" value
    def movement(self):
        # Enemy will move up until it reaches its highest point of travel before turning around
        if self.facing == "up":
            self.y_change -= ENEMY_SPEED
            self.movement_loop -= 1
            if self.movement_loop <= -self.max_travel:
                self.facing = "down"

        # Enemy will move down until it reaches its lowest point of travel before turning around
        if self.facing == "down":
            self.y_change += ENEMY_SPEED
            self.movement_loop += 1
            if self.movement_loop >= self.max_travel:
                self.facing = "up"



# Fighter class that creates the stats and appearance of each possible fighter
class Fighter():
    global enemy_target
    def __init__(self, game, pos_x, pos_y, name, max_hp, attack, special, spmeter, defense, image):

        # Loads each fighter onto the screen when the battle sequence starts
        super().__init__()
        self.game = game
        self._layer = PLAYER_LAYER

        # Initializes the fundamentals of each fighter (stats, appearance, position)
        self.name = name
        self.x = pos_x
        self.y = pos_y
        self.width = BATTLE_SIZE[0]
        self.height = BATTLE_SIZE[1]
        self.max_hp = max_hp
        self.hp = max_hp
        self.attack = attack
        self.special = special
        self.spmeter = spmeter
        self.sp = spmeter
        self.defense = defense
        self.alive = True

        # Creates the hitbox of each fighter
        self.image = pygame.Surface([self.width, self.height])
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

        # Loads the specific texture of each fighter at their designated position during battle
        self.image.blit(image, (0, 0))
        self.image.set_colorkey(BLACK)

    # Draws the texture of each loaded fighter in the fight at the right position
    def draw(self, canvas):
        canvas.blit(self.image, self.rect)

    # Normal attack function that each Fighter can use whenever
    def strike(self, target):
        rng = random.randint(-10, 10)
        damage = self.attack + rng
        target.hp -= damage

        # Prevents their health value from going below 0
        if target.hp < 1:
            target.hp = 0
            target.alive = False

    # Magic attack function that each Fighter can use if they have enough "SP"
    def magic_strike(self, target):
        rng = random.randint(-20, 20)
        damage = self.special + rng
        target.hp -= damage

        # Prevents their health value from going below 0
        if target.hp < 1:
            target.hp = 0
            target.alive = False

    # Retreat function that randomly determines if the player can successfully retreat from a battle
    def run(self, consent):
        global flee

        # Randomly determines the success of each retreat attempt, with a 75% accuracy
        rng = random.randint(0, 3)
        flee += consent

        # Each time the button is pressed, the "flee" counter will go up,
        # requiring at least 2 clicks before a retreat is possible
        if flee > 1:
            if rng != 3:
                flee = 0
                return True



# Health bar class that calculates and shows the current health and magic of each entity in the fight
class HealthBar():

    # Initializes the properties of the health and sp bar, determining its location and amount
    def __init__(self, pos_x, pos_y, hp, max_hp, sp, max_sp, canvas):
        self.x = pos_x
        self.y = pos_y
        self.hp = hp
        self.sp = sp
        self.max_hp = max_hp
        self.max_sp = max_sp
        self.canvas = canvas

    # A function that displays the max health and current health of each fighter at any point in the fight
    def drawHP(self, hp):
        self.hp = hp
        ratio = (self.hp / self.max_hp)
        pygame.draw.rect(self.canvas, RED, (self.x, self.y, 325, 20))
        pygame.draw.rect(self.canvas, GREEN, (self.x, self.y, 325 * ratio, 20))

    # A function that displays the max SP and current SP of each fighter at any point in the fight
    def drawSP(self, sp):
        self.sp = sp
        ratio = (self.sp / self.max_sp)
        pygame.draw.rect(self.canvas, LAVENDER, (self.x, self.y + 20, 325, 20))
        pygame.draw.rect(self.canvas, MAGENTA, (self.x, self.y + 20, 325 * ratio, 20))



# Class that sets up the corruption timer that slowly drains overtime
class Countdown():
    # Initializes the key parameters to make the timer function
    def __init__(self, pos_x, pos_y, time, max_time, canvas):
        self.x = pos_x
        self.y = pos_y
        self.time = time
        self.max_time = max_time
        self.canvas = canvas

    # Displays the timer visually of the corruption getting worse while the game is playing
    def drawTimer(self, time):
        self.time = time
        ratio = (self.time / self.max_time)
        pygame.draw.rect(self.canvas, RED, (self.x, self.y, 485, 40))
        pygame.draw.rect(self.canvas, GREEN, (self.x, self.y, 485 * ratio, 40))



# Barrier class that determines the properties and hitbox of any barrier like object in the game while free roaming
class Barrier(pygame.sprite.Sprite):

    # Initializes the properties of walls and other barriers
    def __init__(self, game, pos_x, pos_y, image):

        # Loads each wall object into the game
        super().__init__()
        self.game = game
        self._layer = BLOCK_LAYER
        self.groups = self.game.all_sprites, self.game.obstacles
        pygame.sprite.Sprite.__init__(self, self.groups)

        # Determines the dimensions of each wall object
        self.x = pos_x * TILESIZE
        self.y = pos_y * TILESIZE
        self.width = WALL_SIZE[0]
        self.height = WALL_SIZE[1]
        self.image = pygame.Surface([self.width, self.height])

        # Hitbox of the wall
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

        # Loads each barrier texture at its correct position
        self.image.blit(image, (0, 0))



# Attack class that deals with the animation and location of the free roam attack
class Attack(pygame.sprite.Sprite):

    # Initializes the properties of the sprite and object used for the attack
    def __init__(self, game, pos_x, pos_y):
        global squeaky

        # Loading Texture of the sprite used
        hammer = pygame.image.load("Red_Squeaky.png")
        squeaky = pygame.transform.scale(hammer, HAMMER_SIZE)

        # Loads in the free roaming attack
        self.game = game
        self._layer = PLAYER_LAYER
        self.groups = self.game.all_sprites, self.game.attacks
        pygame.sprite.Sprite.__init__(self, self.groups)

        # Determines the position, size, and length of the attack
        self.x = pos_x
        self.y = pos_y
        self.width = HAMMER_SIZE[0]
        self.height = HAMMER_SIZE[1]
        self.attack_animation = 0
        self.image = pygame.Surface([self.width, self.height])

        # Hitbox of the attack
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y

    # Refreshes the attack animation overtime
    def update(self):
        self.animate()
        self.attack()

    # Checks if an enemy sprite is colliding with the hammer sprite,
    # and will activate the battle sequence if a collision is detected
    def attack(self):
        hits = pygame.sprite.spritecollide(self, self.game.enemies, True)
        if hits:
            self.game.battle_screen()
            # Removes the enemy from the free roam screen once the collision occurs
            total_enemies.pop(0)

    # Orientates the attack in the proper direction depending on where the player is facing
    def animate(self):
        direction = self.game.player.facing
        self.image.blit(squeaky, (0, 0))
        self.image.set_colorkey(BLACK)

        # Places the attack animation above the player
        if direction == "up":
            self.attack_animation += 1
            if self.attack_animation >= 12:
                self.kill()

        # Places the attack animation below the player
        if direction == "down":
            self.attack_animation += 1
            if self.attack_animation >= 12:
                self.kill()

        # Places the attack animation to the left of the player
        if direction == "left":
            self.attack_animation += 1
            if self.attack_animation >= 12:
                self.kill()

        # Places the attack animation to the right of the player
        if direction == "right":
            self.attack_animation += 1
            if self.attack_animation >= 12:
                self.kill()



# Button class that determines the appearance, dimensions, and functions of the buttons in game
class Button:
    def __init__(self, pos_x, pos_y, width, height, foreground, background, content, fontsize):
        # The font for the buttons made in the game
        self.font = pygame.font.Font("GlitchingDemoRegular.ttf", fontsize)

        # Determines the dimensions and content of each button
        self.content = content
        self.x = pos_x
        self.y = pos_y
        self.width = width
        self.height = height
        self.fg = foreground
        self.bg = background

        # Gets the hitbox and visual elements of each button
        self.image = pygame.Surface((self.width, self.height))
        self.image.fill(self.bg)
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        self.text = self.font.render(self.content,True, self.fg)
        self.text_rect = self.text.get_rect(center = (self.width/2, self.height/2))
        self.image.blit(self.text, self.text_rect)

        # Separate colour used to put a button hitbox over sprites
        self.image.set_colorkey(GRAY)

    # Main function to determine whether a button is clicked successfully to perform an action
    def is_pressed(self, pos, pressed):
        if self.rect.collidepoint(pos):
            if pressed[0]:
                return True
            return False
        return False